# Transcript: Persona 1 — Victim / Entitled / Self-Centric

**Profile:** Mid-level analyst, project got de-prioritized without notice, spent afternoon in back-to-back meetings that "could have been emails."

---

**[START]**  
> Good evening. You made it through another day. This reflection won't take long — just a few honest questions about how you showed up. No right answers. Just noticing.

→ *Employee clicks: Begin*

---

**[A1_OPEN] — Axis 1 begins**  
> Before we dig in — if today had a weather report, what would it be?

→ **"Stormy: friction, tension, push-back"**

*Signal: none | Routes to: A1_Q1_LOW*

---

**[A1_Q1_LOW]**  
> Sounds like the day had some friction. When things got difficult, what did you do?

→ **"I felt stuck and couldn't find a way forward"**

*Signal: axis1:external | Routes to: A1_D1B → A1_Q2_EXTERNAL*

---

**[A1_Q2_EXTERNAL]**  
> Think about one moment today where something didn't go as planned. What was your actual first thought?

→ **"'Whose fault is this?'"**

*Signal: axis1:external | Routes to: A1_D2C → A1_R_EXTERNAL*

---

**[A1_R_EXTERNAL] — Reflection**  
> When a day pushes hard, attention naturally goes outward — to circumstances, to others. That's human. But somewhere in today — maybe a small moment — you did make a call. Even deciding to wait was a call. What was yours?

→ *Employee clicks: Continue*

*Signal: axis1:external | Routes to: BRIDGE_1_2*

---

**[BRIDGE_1_2]**  
> You've looked at how you navigated today. Now let's look at what you gave.

*(auto-advances after 1.8s)*

---

**[A2_OPEN] — Axis 2 begins**  
> Today, which of these moments happened? Pick the one that feels most true.

→ **"I felt frustrated that others weren't doing their share"**

*Signal: none | Routes to: A2_D0 → A2_Q1_ENTITLEMENT*

---

**[A2_Q1_ENTITLEMENT]**  
> That feeling of being underrecognized or carrying more — did it affect how you engaged with the work itself?

→ **"Yes — I pulled back effort as a response"**

*Signal: axis2:entitlement | Routes to: A2_D1B → A2_Q2_ENTITLEMENT*

---

**[A2_Q2_ENTITLEMENT]**  
> Thinking about your work today overall — how would you describe your posture toward it?

→ **"I was trying to avoid mistakes more than create value"**

*Signal: axis2:entitlement | Routes to: A2_D2C → A2_R_ENTITLEMENT*

---

**[A2_R_ENTITLEMENT] — Reflection**  
> Today the ledger of what you were owed was fairly visible to you. That awareness is real — fairness matters, and your effort deserves acknowledgment. And: the work you do when recognition isn't guaranteed is also information about who you are. Both things are true.

→ *Employee clicks: Continue*

*Signal: axis2:entitlement | Routes to: BRIDGE_2_3*

---

**[BRIDGE_2_3]**  
> You've looked at what you navigated and what you gave. One more lens: how wide was your view today?

*(auto-advances)*

---

**[A3_OPEN] — Axis 3 begins**  
> When you think about today's biggest challenge or moment, who was in the frame?

→ **"Mostly me — my stress, my goals, my problem"**

*Signal: none | Routes to: A3_D0 → A3_Q1_SELF*

---

**[A3_Q1_SELF]**  
> Fair — some challenges are genuinely personal. Was there anyone else touched by how today went, even indirectly?

→ **"Not really — this one was contained to me"**

*Signal: axis3:self | Routes to: A3_D1 → A3_Q2_SELF*

---

**[A3_Q2_SELF]**  
> Imagine a colleague had today instead of you. What would you notice about their experience that you might be missing about your own?

→ **"They'd feel the same way I do — it's genuinely difficult"**

*Signal: axis3:self | Routes to: A3_D2 → A3_R_SELF*

---

**[A3_R_SELF] — Reflection**  
> Today your attention was close — to yourself, your challenge, your navigation of the day. That's not selfishness; sometimes survival requires it. What you just imagined — the compassion you'd extend to a colleague in the same situation — you can extend that inward too.

→ *Employee clicks: Continue*

*Signal: axis3:self | Routes to: SUMMARY*

---

**[SUMMARY]**

| Axis | Signal Tally | Dominant |
|------|-------------|----------|
| Axis 1 (Locus) | external: 3, internal: 0 | **external** |
| Axis 2 (Orientation) | entitlement: 2, contribution: 0 | **entitlement** |
| Axis 3 (Radius) | self: 2, mid: 0, altrocentric: 0 | **self** |

**Summary template key:** `external_entitlement_self`

> **Today was genuinely hard. You're tired, and that's real. When everything feels out of your hands and the recognition isn't there, it's a small act of courage to just close the day and try again.**
> 
> *You said today felt like "Stormy: friction, tension, push-back."*

---

**[END]**  
> See you tomorrow.

---

## Path trace (non-decision nodes visited):
START → A1_OPEN → A1_Q1_LOW → A1_Q2_EXTERNAL → A1_R_EXTERNAL → BRIDGE_1_2 → A2_OPEN → A2_Q1_ENTITLEMENT → A2_Q2_ENTITLEMENT → A2_R_ENTITLEMENT → BRIDGE_2_3 → A3_OPEN → A3_Q1_SELF → A3_Q2_SELF → A3_R_SELF → SUMMARY → END

**Total: 17 nodes | 6 questions answered | ~5 minutes**
