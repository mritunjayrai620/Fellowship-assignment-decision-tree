# Daily Reflection Tree — Submission

**DT Fellowship Assignment | Role Simulation**

---

## Repository Structure

```
/tree/
  reflection-tree.json          ← Part A: full tree data (50 nodes, JSON)
/agent/
  reflection-agent.html         ← Part B: runnable web agent (single file, no server needed)
/transcripts/
  persona-1-transcript.md       ← Victim / Entitled / Self-centric path
  persona-2-transcript.md       ← Victor / Contributing / Altrocentric path
write-up.md                     ← Design rationale (2 pages)
README.md                       ← This file
```

---

## Part A: Reading the Tree

Open `tree/reflection-tree.json`. Each node has:

- `id` — unique identifier
- `parentId` — tree parent (builds hierarchy)
- `type` — `start | question | decision | reflection | bridge | summary | end`
- `text` — what the employee sees (may contain `{placeholder}` interpolations)
- `options` — for questions: pipe-separated choices; for decisions: routing rules
- `target` — explicit jump target (overrides child lookup)
- `signal` — what to tally in state (e.g. `axis1:internal`)
- `axis` — which of the 3 axes this question belongs to (1, 2, or 3)

**Decision node routing rule format:**
```
answer=<exact option text>:<target node id>
```

**Signal tally format:**
```
axis1:internal → state.signals.axis1.internal += 1
```

**Summary template lookup:**
```
key = ${axis1.dominant}_${axis2.dominant}_${axis3.dominant}
→ 12 deterministic templates covering all combinations
```

### Tree Stats

| Requirement | Minimum | This Tree |
|-------------|---------|-----------|
| Total nodes | 25+ | **50** |
| Question nodes | 8+ | **14** |
| Decision nodes | 4+ | **13** |
| Reflection nodes | 4+ | **8** |
| Bridge nodes | 2+ | **2** |
| Summary nodes | 1+ | **1** |
| Axes covered | All 3 | **All 3** |

---

## Part B: Running the Agent

No server, no dependencies. Just open `agent/reflection-agent.html` in any modern browser.

The agent:
- Loads the tree from embedded JSON (no LLM API calls)
- Walks nodes, rendering each by type
- Branches deterministically based on selected answers
- Accumulates signals (tallies) per axis
- Interpolates reflection text with earlier answers
- Selects the summary template from a 12-entry lookup table

**To verify no LLM calls:** Open browser DevTools → Network tab → run through a full session. Zero external requests.

---

## Guardrails Against AI Hallucination (Design)

This is a deterministic system by architecture:

1. **No LLM at runtime.** The agent is pure HTML/JS. All text is pre-authored.
2. **Fixed options only.** No free-text input means no classification ambiguity.
3. **Lookup tables, not generation.** Summary text comes from 12 keyed templates. Same key → same text, always.
4. **String interpolation, not synthesis.** `{A1_OPEN.answer}` replaces a placeholder with the exact string the employee clicked.
5. **Auditable paths.** Every conversation can be reconstructed by tracing node IDs in the JSON.

---

## Psychological Sources

- Rotter, J.B. (1954). *Social learning and clinical psychology.* — Axis 1 framework
- Dweck, C. (2006). *Mindset: The New Psychology of Success.* — Growth/fixed mindset informing agency questions  
- Campbell, W.K. et al. (2004). Psychological entitlement. *Journal of Personality.* — Axis 2 invisible-entitlement design
- Organ, D.W. (1988). *Organizational Citizenship Behavior.* — Contribution framing for Axis 2
- Maslow, A.H. (1969). *Theory Z.* — Self-transcendence as Axis 3 goal state
- Batson, C.D. (2011). *Altruism in Humans.* — Perspective-taking question design for Axis 3
