# Transcript: Persona 2 — Victor / Contributing / Altrocentric

**Profile:** Senior product manager, shipped a feature sprint that was two weeks behind, stayed back to help a junior teammate debug a blocker.

---

**[START]**  
> Good evening. You made it through another day. This reflection won't take long — just a few honest questions about how you showed up. No right answers. Just noticing.

→ *Employee clicks: Begin*

---

**[A1_OPEN] — Axis 1 begins**  
> Before we dig in — if today had a weather report, what would it be?

→ **"Sunny: clear, things flowed"**

*Signal: none | Routes to: A1_Q1_HIGH*

---

**[A1_Q1_HIGH]**  
> You had a relatively clear day. When something went well, what do you think made it happen?

→ **"I adapted when the original plan didn't work"**

*Signal: axis1:internal | Routes to: A1_D1 → A1_Q2_INTERNAL*

---

**[A1_Q2_INTERNAL]**  
> Think about one moment today where something didn't go as planned. What was your actual first thought?

→ **"'What can I do right now?'"**

*Signal: axis1:internal | Routes to: A1_D2 → A1_R_INTERNAL*

---

**[A1_R_INTERNAL] — Reflection**  
> You spotted the edge of your control and moved toward it — not away. That's not something everyone does automatically. Some days that instinct is louder than others. Notice it was there today.

→ *Employee clicks: Continue*

*Signal: axis1:internal | Routes to: BRIDGE_1_2*

---

**[BRIDGE_1_2]**  
> You've looked at how you navigated today. Now let's look at what you gave.

*(auto-advances after 1.8s)*

---

**[A2_OPEN] — Axis 2 begins**  
> Today, which of these moments happened? Pick the one that feels most true.

→ **"I helped someone with something outside my job description"**

*Signal: none | Routes to: A2_D0 → A2_Q1_CONTRIBUTION*

---

**[A2_Q1_CONTRIBUTION]**  
> When you helped or gave extra today — what was the honest reason behind it?

→ **"I did it because it needed doing and I was there"**

*Signal: axis2:contribution | Routes to: A2_D1 → A2_Q2_CONTRIBUTION*

---

**[A2_Q2_CONTRIBUTION]**  
> Thinking about your work today overall — how would you describe your posture toward it?

→ **"I was thinking about impact: who does this serve?"**

*Signal: axis2:contribution | Routes to: A2_D2 → A2_R_CONTRIBUTION*

---

**[A2_R_CONTRIBUTION] — Reflection**  
> You spent energy today giving — to a person, to an outcome, to something beyond checking boxes. That's not nothing. It's what separates work that feels meaningful from work that just gets done. Notice that instinct in yourself.

→ *Employee clicks: Continue*

*Signal: axis2:contribution | Routes to: BRIDGE_2_3*

---

**[BRIDGE_2_3]**  
> You've looked at what you navigated and what you gave. One more lens: how wide was your view today?

*(auto-advances)*

---

**[A3_OPEN] — Axis 3 begins**  
> When you think about today's biggest challenge or moment, who was in the frame?

→ **"My team — we were in it together"**

*Signal: none | Routes to: A3_D0 → A3_Q1_ALTO*

---

**[A3_Q1_ALTO]**  
> Your frame was wider today — team or beyond. Did that perspective change how you approached the work?

→ **"Yes — I made different choices because of it"**

*Signal: axis3:altrocentric | Routes to: A3_D1C → A3_Q2_ALTO*

---

**[A3_Q2_ALTO]**  
> You held a wider view today. Thinking about tomorrow — what's one small thing you could do that would make someone else's day marginally easier?

→ **"Share something I learned today that might help someone else"**

*Signal: axis3:altrocentric | Routes to: A3_D2C → A3_R_ALTO*

---

**[A3_R_ALTO] — Reflection**  
> You carried something beyond yourself today — a team, a user, a mission. That's not common. Maslow called this self-transcendence: the orientation that generates meaning even when personal outcomes are uncertain. You touched that today.

→ *Employee clicks: Continue*

*Signal: axis3:altrocentric | Routes to: SUMMARY*

---

**[SUMMARY]**

| Axis | Signal Tally | Dominant |
|------|-------------|----------|
| Axis 1 (Locus) | internal: 3, external: 0 | **internal** |
| Axis 2 (Orientation) | contribution: 2, entitlement: 0 | **contribution** |
| Axis 3 (Radius) | altrocentric: 2, mid: 0, self: 0 | **altrocentric** |

**Summary template key:** `internal_contribution_altrocentric`

> **That's a strong day. You stayed in the driver's seat, gave freely, and kept others in view. Not every day looks like this — remember it.**
> 
> *You said today felt like "Sunny: clear, things flowed."*

---

**[END]**  
> See you tomorrow.

---

## Path trace (non-decision nodes visited):
START → A1_OPEN → A1_Q1_HIGH → A1_Q2_INTERNAL → A1_R_INTERNAL → BRIDGE_1_2 → A2_OPEN → A2_Q1_CONTRIBUTION → A2_Q2_CONTRIBUTION → A2_R_CONTRIBUTION → BRIDGE_2_3 → A3_OPEN → A3_Q1_ALTO → A3_Q2_ALTO → A3_R_ALTO → SUMMARY → END

**Total: 17 nodes | 6 questions answered | ~5 minutes**

---

## Comparison with Persona 1

| Dimension | Persona 1 | Persona 2 |
|-----------|-----------|-----------|
| Opening question | Stormy | Sunny |
| A1 routing | Q1_LOW → Q2_EXTERNAL | Q1_HIGH → Q2_INTERNAL |
| A1 reflection | "Where was your choice?" | "Notice that instinct" |
| A2 routing | ENTITLEMENT path | CONTRIBUTION path |
| A2 reflection | Fairness + ledger | Meaning beyond boxes |
| A3 routing | SELF path | ALTO path |
| A3 reflection | "Extend compassion inward" | "Self-transcendence" |
| Summary key | external_entitlement_self | internal_contribution_altrocentric |
| Summary tone | Gentle validation of a hard day | Recognition of an unusual day |

Both employees completed the **same 6 questions** and visited the **same number of nodes (17)**. The branching produced **entirely different reflection text** at each axis — all from a lookup table, no generation.
