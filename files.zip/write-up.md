# Write-Up: Daily Reflection Tree Design Rationale

**Author:** Candidate Submission | **Assignment:** DT Fellowship — Daily Reflection Tree  
**Part A Design Rationale | Max 2 pages**

---

## Why These Questions

The central design constraint I held throughout: *these questions must be answerable by a tired person at 7pm and still be worth answering*.

That eliminates abstract introspection ("Did you demonstrate a growth mindset today?") and clinical prompting ("Rate your internal locus of control from 1–5"). The questions need to feel like a thoughtful colleague who knows you had a real day.

**Axis 1 (Locus)** opens with a weather metaphor deliberately. Weather is emotionally honest — people don't perform their answer to "how's the weather?" The choice of Sunny/Cloudy/Stormy/Foggy immediately surfaces emotional register without triggering defensiveness. I then follow with behavioral questions ("what did you do?" not "who do you believe you are?") because Rotter's research shows locus of control is revealed through behavioral attribution, not self-report labels.

The second A1 question ("what was your actual first thought?") is designed to probe automatic response, not considered opinion. The key word is *first* — it bypasses the self-improvement persona people activate when reflecting and catches the instinctual framing.

**Axis 2 (Orientation)** had the hardest design problem: entitlement is invisible to the person experiencing it. Campbell et al.'s research shows that entitled individuals genuinely believe their expectations are fair. Asking "are you entitled?" will always produce a false answer.

My solution: ask about concrete moments and let the employee locate themselves. "I felt frustrated that others weren't doing their share" is a thought most people recognize as their own — it doesn't feel like an indictment when you pick it. The follow-up ("did it affect how you engaged with the work?") then surfaces the behavioral consequence of that orientation without moralizing.

**Axis 3 (Radius)** uses a spatial metaphor — "who was in the frame?" — because Batson's perspective-taking research shows that wider concern begins with attention, not intention. Most self-centric people aren't uncaring; they're not *looking*. The question prompts looking without requiring a particular outcome.

The perspective-inversion question ("imagine a colleague had today, not you") is the axis's most important move. It exploits the consistency between interpersonal compassion and self-compassion — most people are gentler toward imagined colleagues than toward themselves. Noticing that gap is itself a form of Maslow's self-transcendence.

---

## How I Designed the Branching

**Core principle: branch on emotion, then drill on behavior.**

The opening question routes to different tonal registers (HIGH vs LOW difficulty days), which allows follow-up questions to land appropriately. A "Sunny" response gets a different second question than a "Stormy" one — not because the psychology changes, but because the same question asked in different contexts reads as empathetic versus tone-deaf.

**Parallel path design:** I used parallel question nodes (A1_Q2_INTERNAL, A1_Q2_MID, A1_Q2_EXTERNAL) with identical text to simplify the branching structure while still allowing signals to accumulate differently. This means the tree has fewer unique question texts, which makes the conversation feel more consistent — the employee doesn't notice they're on different tracks.

**Signal accumulation over binary classification:** Rather than routing to "you are a victim" or "you are a victor" after one question, signals accumulate across multiple questions. The SUMMARY node uses the `axis.dominant` tally to select the reflection template. This handles the messiness of real humans — someone can show internal locus in Q1 and external locus in Q2, and the summary reflects the overall lean rather than overclaiming on one data point.

**The trade-off I made:** Simplicity over granularity. A fully branched tree with unique paths for every combination would be 150+ nodes. I prioritized a smaller, tighter tree that could be fully traced in a reading. The cost is some path consolidation — paths that are meaningfully different emotionally (e.g., "external + low confidence" vs "external + frustrated") sometimes merge at the reflection node. With more time, I'd diverge those.

---

## Psychological Sources

- **Rotter (1954):** Internal-External Locus of Control Scale — provided the conceptual poles for Axis 1 and the method of behavioral attribution questions
- **Dweck (2006), *Mindset*:** Growth vs. fixed mindset distinction — informed the framing of adaptability questions vs. luck/circumstance questions
- **Campbell, Bonacci, Shelton, Exline, Bushman (2004):** *Journal of Personality* — entitlement scale design; specifically the insight that entitlement is a stable trait invisible to its holder
- **Organ (1988):** Organizational Citizenship Behavior — provided the language of discretionary effort and the "beyond formal requirements" framing
- **Maslow (1969), *Theory Z*:** Self-transcendence as peak of hierarchy — provided the philosophical grounding for Axis 3 and the goal of outward orientation
- **Batson (2011):** Altruism research — perspective-taking as cognitive, not purely emotional, act; informed the "imagine a colleague" question design

---

## What I'd Improve With More Time

1. **Axis continuity across sessions.** A single reflection is a data point; a week of reflections is a trend. The tree structure supports this — every path taken leaves a deterministic signal footprint. With persistent state, the SUMMARY could reference "this is the third time this week your frame was narrow after a hard day" — without LLM inference, just pattern lookup.

2. **More divergent A3 paths.** The altrocentric path currently routes quickly to a validating reflection. A more challenging tree would press further: "You said you kept others in view — but did their situation change how you acted, or just how you felt?" That's a meaningful distinction Batson makes — emotional empathy vs. perspective-taking that changes behavior.

3. **Anti-sycophancy in reflections.** Some reflection nodes are warm affirmations. Real growth occasionally needs friction: "You said you helped someone — and also that you noticed whether it would reflect well on you. Which one drove it?" I'd add a node type `challenge` that can follow a reflection for employees who want harder feedback.

4. **A calibration question at START.** Before entering the tree, ask "How honest do you want to be today?" with options ranging from "I need to be gentle with myself tonight" to "Push me — I want an honest read." This would route to softer or sharper question phrasings, without changing the underlying signals collected.

---

*Total design time: ~6 hours. Source reading: Rotter scale, Dweck Chapter 1–3, Organ 1988 abstract + citations, Maslow 1969 excerpt, Batson 2011 review summary.*
